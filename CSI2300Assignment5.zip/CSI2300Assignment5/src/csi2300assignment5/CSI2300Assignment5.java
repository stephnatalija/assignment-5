/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package csi2300assignment5;

import java.io.File;
import java.util.Arrays;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.PrintWriter;
import java.util.Random;




/**
 *
 * @author sstan
 */
public class CSI2300Assignment5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
       //  A simple Java command line application for matrix multication
        /*
       ``1. Get familiar with file input and output in Java
         2. Use Java arrays for storage and computation
       */
        
        int row1;
        int row2;
        int column1;
        int column2; 
        
        int[][] matrix1, matrix2, results; 
        
        if (args.length == 2) {
            // Command line arguments provided
            try {
                matrix1 = readMatrixFromFile(args[0]);
                matrix2 = readMatrixFromFile(args[1]);
                row1 = matrix1.length;
                column1 = matrix1[0].length;
                row2 = matrix2.length;
                column2 = matrix2[0].length;
            } catch (FileNotFoundException e) {
              System.out.println("Error: Incompatible matrices for multiplication.");  
              return; 
            } 
        } else {
            Scanner scan = new Scanner(System.in); 
            System.out.println("Enter the size of matrices");
             int i = scan.nextInt();
             matrix1 = generateRandomMatrix(i, i);
             matrix2 = generateRandomMatrix(i, i);
             
             row1 = i;
             row2 = i;
             column1 = i;
             column2 = i; 
        } // end of else
        
        if (column1 != row2){
            System.out.println("error, matrices are incompatible for multiplication"); 
        } // end of if
        
        results = multiplyMatrices(matrix1, matrix2);
        writeMatrixToFile("matrix3.txt", results); 
    }
    
     private static int[][] readMatrixFromFile(String fileName) throws FileNotFoundException {
        Scanner scanFiles = new Scanner(new File(fileName));
        int row = 0;
        int column = 0; 
        while (scanFiles.hasNextLine()) {
            String[] line = scanFiles.nextLine().split(" ");
            if (column == 0) {
            column = line.length; 
        }
            row++;
        } 
        scanFiles.close();
        
        int[][] matirx = new int[row][column]; 
        scanFiles = new Scanner (new File(fileName));
        int i;
        for (i = 0; i < row; i++) {
            int j;
            for (j = 0; j < column; j++) {
                int[][] matrix = null;
                matrix[i][j] = scanFiles.nextInt();
            }
           scanFiles.close();
        }
        int[][] matrix = null;
        return matrix; 
     }
     
    @SuppressWarnings("empty-statement")
     private static int[][] multiplyMatrices(int[][] A, int[][] B) {
     int rowA = A.length;
     int columnA = A[0].length;
     int columnB = B[0].length; 
     
     int[][] C = new int[rowA][columnB];
     int i;
     for (i = 0; i < rowA; i++) {
        int j;
        for (j = 0; j < rowA; j++ ) {
            int k;
            for (k=0; k < rowA; k++) {
                C[i][j] += A[i][k] * B[k][j];
            }
         
     }
     }
     return C; 
     }
     
 private static void writeMatrixToFile(String fileName, int[][] matrix) throws FileNotFoundException {
     try (PrintWriter write = new PrintWriter (fileName)) {
       for (int[] row : matrix) {
         write.println(Arrays.toString(row).replaceAll("[\\[\\],]", ""));
     }  
     } catch (FileNotFoundException ex) {
       System.out.println("404, file not found"); 
     }
 }    

    private static int[][] generateRandomMatrix(int i, int i0) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
     
}
    

